(() => {
  const existing = document.getElementById('__cg_overlay__');
  if (existing) existing.remove();

  function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(v => v.toString(16).padStart(2, '0')).join('');
  }

  function readColorAt(x, y) {
    const el = document.elementFromPoint(x, y);
    if (!el) return '#000000';
    const cs = getComputedStyle(el);
    let color = cs.backgroundColor;
    if (!color || color === 'rgba(0, 0, 0, 0)' || color === 'transparent') {
      color = cs.color;
    }
    const m = color.match(/\d+/g);
    if (m && m.length >= 3) {
      return rgbToHex(parseInt(m[0], 10), parseInt(m[1], 10), parseInt(m[2], 10));
    }
    return '#000000';
  }

  function sendColor(hex) {
    try {
      chrome.runtime.sendMessage({ type: 'COLOR_PICKED', hex });
    } catch (e) {}
  }

  const overlay = document.createElement('div');
  overlay.id = '__cg_overlay__';
  Object.assign(overlay.style, {
    position: 'fixed',
    inset: '0',
    cursor: 'crosshair',
    zIndex: '2147483647',
    background: 'rgba(0, 0, 0, 0.08)',
  });

  const tip = document.createElement('div');
  Object.assign(tip.style, {
    position: 'fixed',
    top: '20px',
    left: '50%',
    transform: 'translateX(-50%)',
    padding: '10px 18px',
    background: 'rgba(20,20,24,0.95)',
    color: '#fff',
    fontSize: '13px',
    fontFamily: 'system-ui, sans-serif',
    borderRadius: '8px',
    zIndex: '2147483648',
    pointerEvents: 'none',
    boxShadow: '0 4px 20px rgba(0,0,0,0.4)',
  });

  const preview = document.createElement('div');
  Object.assign(preview.style, {
    position: 'fixed',
    width: '24px',
    height: '24px',
    borderRadius: '50%',
    border: '2px solid #fff',
    boxShadow: '0 0 0 1px #000',
    pointerEvents: 'none',
    zIndex: '2147483648',
    transform: 'translate(-50%, -50%)',
    display: 'none',
  });

  function cleanup() {
    overlay.remove();
    tip.remove();
    preview.remove();
    document.removeEventListener('keydown', onKey, true);
  }

  function onKey(e) {
    if (e.key === 'Escape') cleanup();
  }

  overlay.addEventListener('mousemove', (e) => {
    const hex = readColorAt(e.clientX, e.clientY);
    tip.textContent = hex.toUpperCase() + ' - clic para capturar - ESC para cancelar';
    preview.style.display = 'block';
    preview.style.left = e.clientX + 'px';
    preview.style.top = e.clientY + 'px';
    preview.style.background = hex;
  });

  overlay.addEventListener('mouseleave', () => {
    preview.style.display = 'none';
  });

  overlay.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    const hex = readColorAt(e.clientX, e.clientY);
    cleanup();
    sendColor(hex);
  }, true);

  document.addEventListener('keydown', onKey, true);
  document.documentElement.appendChild(overlay);
  document.documentElement.appendChild(tip);
  document.documentElement.appendChild(preview);

  tip.textContent = 'Mueve el raton y haz clic para capturar. ESC para cancelar.';
})();