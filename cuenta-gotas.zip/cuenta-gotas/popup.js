function hexToRgb(hex) {
  const h = hex.replace('#', '');
  return {
    r: parseInt(h.substring(0, 2), 16),
    g: parseInt(h.substring(2, 4), 16),
    b: parseInt(h.substring(4, 6), 16),
  };
}

function rgbToHex({ r, g, b }) {
  return (
    '#' +
    [r, g, b]
      .map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0'))
      .join('')
  );
}

function rgbToHsl({ r, g, b }) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h, s, l = (max + min) / 2;

  if (max === min) {
    h = s = 0;
  } else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }
    h /= 6;
  }
  return { h: h * 360, s: s * 100, l: l * 100 };
}

function hslToRgb({ h, s, l }) {
  h /= 360; s /= 100; l /= 100;
  let r, g, b;
  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p, q, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return { r: r * 255, g: g * 255, b: b * 255 };
}

function generatePalette(hex) {
  const rgb = hexToRgb(hex);
  const hsl = rgbToHsl(rgb);
  const h = hsl.h;
  const s = hsl.s;
  const l = hsl.l;

  const variants = [
    { name: 'Base',        h: h,                          s: s,                     l: l },
    { name: 'Analogo-',    h: (h - 30 + 360) % 360,       s: s,                     l: l },
    { name: 'Analogo+',    h: (h + 30) % 360,             s: s,                     l: l },
    { name: 'Complemento', h: (h + 180) % 360,            s: s,                     l: l },
    { name: 'Triada',      h: (h + 120) % 360,            s: s,                     l: l },
    { name: 'Triada+',     h: (h + 240) % 360,            s: s,                     l: l },
    { name: 'Claro',       h: h,                          s: s,                     l: Math.min(100, l + 20) },
    { name: 'Oscuro',      h: h,                          s: s,                     l: Math.max(0, l - 20) },
    { name: 'Pastel',      h: h,                          s: Math.max(0, s - 35),   l: Math.min(95, l + 15) },
    { name: 'Saturado',    h: h,                          s: Math.min(100, s + 25), l: l },
  ];

  return variants.map(v => {
    const rgb2 = hslToRgb({ h: v.h, s: v.s, l: v.l });
    return { name: v.name, hex: rgbToHex(rgb2), rgb: rgb2 };
  });
}

const pickBtn    = document.getElementById('pickBtn');
const result     = document.getElementById('result');
const empty      = document.getElementById('empty');
const mainSwatch = document.getElementById('mainSwatch');
const mainHex    = document.getElementById('mainHex');
const hexVal     = document.getElementById('hexVal');
const rgbVal     = document.getElementById('rgbVal');
const hslVal     = document.getElementById('hslVal');
const paletteEl  = document.getElementById('palette');

let currentHex = null;

function renderResult(hex) {
  currentHex = hex;
  const rgb = hexToRgb(hex);
  const hsl = rgbToHsl(rgb);

  empty.hidden = true;
  result.hidden = false;

  mainSwatch.style.background = hex;
  mainHex.textContent = hex.toUpperCase();

  hexVal.textContent = hex.toUpperCase();
  rgbVal.textContent = 'rgb(' + rgb.r + ', ' + rgb.g + ', ' + rgb.b + ')';
  hslVal.textContent =
    'hsl(' + Math.round(hsl.h) + ', ' + Math.round(hsl.s) + '%, ' + Math.round(hsl.l) + '%)';

  paletteEl.innerHTML = '';
  generatePalette(hex).forEach(c => {
    const sw = document.createElement('div');
    sw.className = 'swatch';
    sw.style.background = c.hex;
    sw.title = c.name + ': ' + c.hex;
    sw.innerHTML = '<span>' + c.hex.toUpperCase() + '</span>';
    sw.addEventListener('click', () => copy(c.hex, 'Copiado ' + c.hex));
    paletteEl.appendChild(sw);
  });

  chrome.storage.local.set({ lastColor: hex });
}

function copy(text, msg) {
  navigator.clipboard.writeText(text).then(() => showToast(msg || 'Copiado'));
}

function showToast(text) {
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = text;
  document.body.appendChild(t);
  requestAnimationFrame(() => t.classList.add('show'));
  setTimeout(() => {
    t.classList.remove('show');
    setTimeout(() => t.remove(), 300);
  }, 1200);
}

pickBtn.addEventListener('click', async () => {
  if ('EyeDropper' in window) {
    try {
      const ed = new EyeDropper();
      const res = await ed.open();
      if (res && res.sRGBHex) {
        renderResult(res.sRGBHex);
        showToast('Color capturado');
      }
    } catch (e) {
      showToast('Captura cancelada');
    }
    return;
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) {
    showToast('No hay pestana activa');
    return;
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js'],
    });
    window.close();
  } catch (e) {
    console.warn(e);
    showToast('No se puede capturar aqui');
  }
});

document.getElementById('copyHex').addEventListener('click', () => {
  if (currentHex) copy(currentHex.toUpperCase(), 'HEX copiado');
});

document.getElementById('copyRgb').addEventListener('click', () => {
  if (!currentHex) return;
  const { r, g, b } = hexToRgb(currentHex);
  copy('rgb(' + r + ', ' + g + ', ' + b + ')', 'RGB copiado');
});

chrome.storage.local.get('lastColor', ({ lastColor }) => {
  if (lastColor) renderResult(lastColor);
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'COLOR_PICKED' && msg.hex) {
    renderResult(msg.hex);
  }
});