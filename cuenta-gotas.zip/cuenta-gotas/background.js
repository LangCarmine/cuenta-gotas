chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg && msg.type === 'COLOR_PICKED' && msg.hex) {
    chrome.storage.local.set({ lastColor: msg.hex });
  }
});